package controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import models.Ideas;
import models.IdeasDAO;

public class DAOcontrol {

	public static void main(String[] args) throws SQLException, IOException {

		IdeasDAO dao = new IdeasDAO();
		ArrayList<Ideas> allVehicles = null;
		Ideas ide= null;

		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);

		System.out.println(""
				+ "----------------------------- \n"
				+ "Vehicle Inventory System \n"
				+ "Choose from theese options \n"
				+ "----------------------------- \n"
				+ "1 - Retrieve all vehicles \n"
				+ "2 - Search for vehicle \n"
				+ "3 - Insert new vehicle into database \n"
				+ "4 - Update existing vehicle details \n"
				+ "5 - Delete vehicle from database \n"
				+ "6 - Exit \n"
				+ "Enter choice > ");

		int vChoice = (int) scanner.nextFloat();

		switch (vChoice) {
		case 1:
			if (vChoice == vChoice) {

			/*	allVehicles = dao.getAllIdeas();
				for (Vehicle v : allVehicles) {
					System.out.println("-------");
					System.out.println(v);*/
				}
			break;
			
		case 2:
			System.out.println("Enter values1");
			String difficulty=scanner.nextLine();
			scanner.nextLine();
			System.out.println("Enter values2");
			String type=scanner.nextLine();
			scanner.nextLine();
			System.out.println("Enter values3 ");
			String ideas=scanner.nextLine();
			scanner.nextLine();
			if (vChoice == vChoice) {
                ide= new Ideas(difficulty, type, ideas);
				dao.insertIdeas(ide);
			}
			break;
	
}
	}
}
	/*	case 4:
			if (vChoice == vChoice) {

				dao.updateVehicle(null, vChoice);
			}
			break;
		case 5:
			if (vChoice == vChoice) {

				dao.deleteVehicle(vChoice);
			}
			break;
		case 6:
			if (vChoice == vChoice) {
				System.out.println("Goodbye!");
				System.exit(0);
			}
			break;*/
		
		