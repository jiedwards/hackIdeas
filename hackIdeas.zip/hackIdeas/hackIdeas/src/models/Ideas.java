package models;

public class Ideas {

	public Ideas() {

	}

	private String difficulty;
	private String type;
	private String ideas;

	public Ideas(String difficulty, String type, String ideas) {
	this.difficulty=difficulty;
	this.type=type;
	this.ideas=ideas;
	}

	public String getDifficulty() {
		return difficulty;
	}

	public String getType() {
		return type;
	}

	public String getIdeas() {
		return ideas;
	}

	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setIdeas(String ideas) {
		this.ideas = ideas;
	}

}
